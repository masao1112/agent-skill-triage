Only organize user-selected notes. Ask before changing files.
